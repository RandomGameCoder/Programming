import mysql.connector
con = mysql.connector.connect(host='localhost',user='root',passwd='root')
print(con)
